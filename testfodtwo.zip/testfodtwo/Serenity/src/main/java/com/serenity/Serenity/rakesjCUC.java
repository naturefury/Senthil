package com.serenity.Serenity;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;
@RunWith(Cucumber.class)
@CucumberOptions(format={"SimpleHtmlReport:report/smokeTest.html"},
features={"cucumber.Features/"})
public class rakesjCUC {
@Given("^User is on home page$")
public void user_is_on_home_page() throws Exception {
    
	// Write code here that turns the phrase above into concrete actions
	
	System.out.println("Cucumber executed Given statement");
    throw new PendingException();
}

@When("^User has to navigate home page$")
public void user_has_to_navigate_home_page() throws Exception {
    // Write code here that turns the phrase above into concrete actions

	System.out.println("url is navigated"+"www.gmail.com");

    throw new PendingException();
}

@When("^user enters user name$")
public void user_enters_user_name() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	System.out.println("Username is:"+ "rajesh");
	
    throw new PendingException();
}

@When("^Password$")
public void password() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	System.out.println("Password is:"+ "rajesh");

    throw new PendingException();
}

@Then("^User should able to see message$")
public void user_should_able_to_see_message() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	System.out.println("Succesfully logged into page");
    throw new PendingException();
}





}
