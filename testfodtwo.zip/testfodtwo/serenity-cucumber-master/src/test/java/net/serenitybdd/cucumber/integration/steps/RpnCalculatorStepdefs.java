package net.serenitybdd.cucumber.integration.steps;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import samples.calculator.RpnCalculator;

import java.util.List;

import static org.junit.Assert.assertEquals;

public class RpnCalculatorStepdefs {
    private RpnCalculator calc;

    @Given("^a calculator I just turned on$")
    public void a_calculator_I_just_turned_on() {
        calc = new RpnCalculator();
    }

    @When("^I add (\\d+) and (\\d+)$")
    public void adding(int arg1, int arg2) {
        calc.push(arg1);
        calc.push(arg2);
        calc.push("+");
    }

    @Given("^I press (.+)$")
    public void I_press(String what) {
        calc.push(what);
    }

    @Then("^the result is (\\d+)$")
    public void the_result_is(Integer expected) {
        assertEquals(expected, calc.value());
    }

//    @Before({"~@foo"})
    @Before
    public void before(Scenario scenario) {
//        scenario.write("Some special text");
//        int i = 0;
    }

    @After
    public void after(Scenario scenario) {
    }

    @Given("^the previous entries:$")
    public void thePreviousEntries(List<Entry> entries) {
        for (Entry entry : entries) {
            calc.push(entry.first);
            calc.push(entry.second);
            calc.push(entry.operation);
        }
    }

    @When("^I enter (\\d+) and (\\d+)$")
    public void entering(int arg1, int arg2) {
        calc.push(arg1);
        calc.push(arg2);
    }


    public class Entry {
        Integer first;
        Integer second;
        String operation;
    }
}
