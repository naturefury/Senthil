package net.serenitybdd.cucumber.integration.steps.thucydides;

import net.thucydides.core.annotations.Step;

/**
 * Created by john on 15/07/2014.
 */
public class SampleSteps {

    public SamplePageObject pageObject;

    @Step
    public void aSimpleStep() { }

    @Step
    public void anotherSimpleStep() {}
}
