package net.serenitybdd.cucumber.integration.steps.thucydides;

/**
 * Created by john on 19/08/2015.
 */
public class GizmoBuyerSteps {
}
