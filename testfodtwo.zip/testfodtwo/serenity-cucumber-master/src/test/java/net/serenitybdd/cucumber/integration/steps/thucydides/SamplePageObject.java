package net.serenitybdd.cucumber.integration.steps.thucydides;

import net.thucydides.core.pages.PageObject;

public class SamplePageObject extends PageObject {}
