High-level requirements that need to be implemented/verified:
[] Generate HTML and JSON test outcomes for each executed scenario
[] Generated test outcome should have a feature tag matching the name of the feature file
[] Generated test outcomes should have epic or capability tags based on the directory structure