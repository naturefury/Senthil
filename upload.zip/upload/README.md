# Gerty

[Gerty] is a open source keyword driven framework using Selenium.

This framework is completed framework with limited functionalities but a stable code which can be used to automate applications in Waterfall model.