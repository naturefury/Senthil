package driver;

public enum DriverType {
    ANDROID,
    IOS
}