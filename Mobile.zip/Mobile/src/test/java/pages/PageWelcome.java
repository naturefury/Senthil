package pages;

import base.Keywords;
import exceptions.ApplicationException;
import exceptions.EnvironmentException;
import helper.Device;
import org.openqa.selenium.By;
import xpath.Matching;

public class PageWelcome extends Keywords {

    String alreadyLoginEmail;

    private String keyBtnLogin="Getgo.Welcome.BtnLogin";
    private String keyBtnSignUp="Getgo.Welcome.BtnSignUp";

    public void launchGetgo() throws EnvironmentException {
	    launchApplication();
    }

    public void launchGetgoFresh() throws EnvironmentException {
        driver=null;
        launchApplication();
    }

    public void doesPageContains(String loginBtnTxt,String signUpBtnTxt,String captionTxt) throws ApplicationException
    {
	    verify.elementIsPresent("Getgo.Welcome.ImgLogo");
        verify.elementTextMatching("Getgo.Welcome.LblCaption",captionTxt);
        verify.elementTextMatching(keyBtnLogin,loginBtnTxt);
        verify.elementTextMatching(keyBtnSignUp,signUpBtnTxt);
    }

    public void clickLogin() throws ApplicationException {
        if(Device.isAndroid()) {
            try {
                click.elementBy(keyBtnLogin);
            } catch (Exception e) {

                click.elementBy(xpathOf.button(Matching.youDecide("NEXT")));
                click.elementBy(xpathOf.button(Matching.youDecide("NEXT")));
                click.elementBy(xpathOf.button(Matching.youDecide("NEXT")));
                click.elementBy(xpathOf.button(Matching.youDecide("NEXT")));
                click.elementBy(xpathOf.button(Matching.youDecide("GET STARTED")));
                click.elementBy(keyBtnLogin);
            }
        }
        else
        {
            try {
                click.elementBy(keyBtnLogin);
            } catch (Exception e) {
                if (driver.findElementByAccessibilityId("ic_profile_landing").isDisplayed()) {
                    alreadyLoginEmail = get.elementText(By.xpath("(XCUIElementTypeStaticText)[2]"));

                    click.elementBy(xpathOf.button(Matching.name("USE PASSWORD")));
                }


            }
        }

    }

    public void clickSignUp() throws ApplicationException {
        click.elementBy(keyBtnSignUp);
    }


}
