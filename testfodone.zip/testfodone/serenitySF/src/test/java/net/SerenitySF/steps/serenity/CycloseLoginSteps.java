package net.SerenitySF.steps.serenity;

import CyclosStepClass.cyclosStepFun;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class CycloseLoginSteps {
	
	@Steps
	cyclosStepFun Enduser;
	
	@Given("^user is on application landing page as \"([^\"]*)\"$")
	public void user_is_on_application_landing_page_as(String HomepageText) throws Exception {
		Enduser.verify_login_PageIs_Correct(HomepageText);
	   
	}

	@When("^user enters in userNameField as \"([^\"]*)\"$")
	public void user_enters_in_userNameField_as(String userName) throws Exception {
		Enduser.enter_UserName(userName);
	   
	}

	@When("^user enters  in passWordField as \"([^\"]*)\"$")
	public void user_enters_in_passWordField_as(String passWord) throws Exception {
		Enduser.enter_password(passWord);
	}

	@When("^user clicked on SignInBUtton$")
	public void user_clicked_on_SignInBUtton() throws Exception {
		Enduser.click_On_SignIn();
	    
	}

	@Then("^user should able to see Welcome to cyclose message with \"([^\"]*)\"$")
	public void user_should_able_to_see_Welcome_to_cyclose_message_with(String HomeText) throws Exception {
		Enduser.verify_Welcome_message(HomeText);
	}



}
