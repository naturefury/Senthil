package net.SerenitySF.pages;

import org.junit.Assert;
import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.DefaultUrl;
@DefaultUrl("https://demo.cyclos.org/#login")   
public class CycloseLoginPage extends PageObject{
           
	    @FindBy(className = "pageHeadingText")
	    WebElementFacade FHeadingText;
	    
	    @FindBy(className = "inputField medium")
	    WebElementFacade userNameField;
	    
	    @FindBy(className = "inputField passwordField authenticationInput medium")
	    WebElementFacade passWordField;
	    
	    @FindBy(className = "actionButtonText")
	    WebElementFacade SignInButton;
	    
	    @FindBy(className = "pageSectionHeading")
	    WebElementFacade WelcomeHomePage;


	    
	    public void VerifyHomePage(String HomepageText) {
	    	FHeadingText.equals(HomepageText);
	    	System.out.println("The current home page text is " +HomepageText);
	    	try { Thread.sleep(2000);}
			catch (InterruptedException e) {}
	                              
	    }
	    
	    public void enterUserName(String userName) {
	    	userNameField.sendKeys(userName);
	    	try { Thread.sleep(2000);}
			catch (InterruptedException e) {}
	    }
	    
	    public void enterpassWord(String passWord) {
	    	passWordField.sendKeys(passWord);
	    	try { Thread.sleep(2000);}
			catch (InterruptedException e) {}
	    }
	    	 public void clickOnSignIn() {
	 	    	SignInButton.click();
	    	 }
	 	    	 public void verifyHomePageTextOfWelcomeScreen(String HomeText) {
	 	    		Assert.assertEquals(HomeText, HomeText);
	 	    		System.out.println("Finally reached the page "+HomeText);
	    	
	                              
	    }
	}

