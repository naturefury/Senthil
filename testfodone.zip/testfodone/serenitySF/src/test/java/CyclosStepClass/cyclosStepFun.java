package CyclosStepClass;

import net.SerenitySF.pages.CycloseLoginPage;
import net.thucydides.core.annotations.Step;

public class cyclosStepFun {

	CycloseLoginPage loginpage;
	
	@Step
	public void verify_login_PageIs_Correct(String HomepageText){
		loginpage.VerifyHomePage(HomepageText);
	}
	@Step
	public void enter_UserName(String userName){
		loginpage.enterUserName(userName);
	}
	
	@Step
	public void enter_password(String passWord){
		loginpage.enterpassWord(passWord);
	}
	@Step
	public void click_On_SignIn(){
		loginpage.clickOnSignIn();
	}
	
	@Step
	public void verify_Welcome_message(String HomeText){
		loginpage.verifyHomePageTextOfWelcomeScreen(HomeText);
	}
}
