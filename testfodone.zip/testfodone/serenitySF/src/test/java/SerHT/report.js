$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resources/features/consult_dictionary/LookupADefinition.feature");
formatter.feature({
  "name": "Hyderabad flights availibilties",
  "description": "",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "Looking available flights for hyderbad",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "The user in tour home page",
  "keyword": "Given "
});
formatter.step({
  "name": "the user provinding username \u003cUserName\u003e",
  "keyword": "When "
});
formatter.step({
  "name": "the user provinding password \u003cPassWord\u003e",
  "keyword": "And "
});
formatter.step({
  "name": "should click on sign In button",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "UserName",
        "PassWord"
      ]
    },
    {
      "cells": [
        "demo",
        "demo"
      ]
    },
    {
      "cells": [
        "rajesh",
        "rajesh"
      ]
    },
    {
      "cells": [
        "ramki",
        "ramki"
      ]
    }
  ]
});
formatter.scenario({
  "name": "Looking available flights for hyderbad",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "The user in tour home page",
  "keyword": "Given "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.step({
  "name": "the user provinding username demo",
  "keyword": "When "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.step({
  "name": "the user provinding password demo",
  "keyword": "And "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.step({
  "name": "should click on sign In button",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "name": "Looking available flights for hyderbad",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "The user in tour home page",
  "keyword": "Given "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.step({
  "name": "the user provinding username rajesh",
  "keyword": "When "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.step({
  "name": "the user provinding password rajesh",
  "keyword": "And "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.step({
  "name": "should click on sign In button",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "name": "Looking available flights for hyderbad",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "The user in tour home page",
  "keyword": "Given "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.step({
  "name": "the user provinding username ramki",
  "keyword": "When "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.step({
  "name": "the user provinding password ramki",
  "keyword": "And "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.step({
  "name": "should click on sign In button",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
});