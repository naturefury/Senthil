package com.cyclos.stepdefination;

import cucumber.api.java.en.Given;

public class StepDefinationThree {
	
	@Given("^I want to enter into scenario scthree$")
	public void i_want_to_enter_into_scenario_scthree() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("sctyhree");
	}

	@Given("^I want to enter into scenario scfour$")
	public void i_want_to_enter_into_scenario_scfour() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("scfour");
	}


}
