package com.cyclos.stepdefination;

import cucumber.api.java.en.Given;

public class StepDefinationTwo {
	
	@Given("^I want to enter into scenario scone$")
	public void i_want_to_enter_into_scenario_scone() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("scone");
	}

	@Given("^I want to enter into scenario sctwo$")
	public void i_want_to_enter_into_scenario_sctwo() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("sctwo");
	}


}
