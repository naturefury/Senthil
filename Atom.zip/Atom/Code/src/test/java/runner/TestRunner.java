package runner;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.time.LocalDateTime;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import com.cucumber.listener.ExtentProperties;
import com.cucumber.listener.Reporter;

import core.Atom;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"features"},
        glue = {"stepdefinitions"},
        plugin = {"com.cucumber.listener.ExtentCucumberFormatter:"}
)

public class TestRunner {
	
	public static Atom atom;
	
	@BeforeClass
    public static void setup() {
		atom = new Atom();
		//logSetup();
        ExtentProperties extentProperties = ExtentProperties.INSTANCE;
        extentProperties.setReportPath(atom.environment().paths().runResults()+"Execution Dashboard.html");
        atom.mobile().setup("SamsungGalaxyS5");
        atom.mobile().start();
    }

    @AfterClass
    public static void CreateExtentReport() {
    	
        Reporter.loadXMLConfig(new File(atom.environment().paths().reportConfiguration()));
        Reporter.setSystemInfo("User Name", System.getProperty("user.name"));
        Reporter.setSystemInfo("Time Zone", System.getProperty("user.timezone"));
        Reporter.setSystemInfo("Machine", "Windows 10 " + "64 Bit");
        Reporter.setSystemInfo("Selenium", "3.12");
        Reporter.setSystemInfo("Maven", "3.5.3");
        Reporter.setSystemInfo("Java Version", "1.8");
        
        /*
	        List<LogEntry> logEntries = atom.mobile().driver().manage().logs().get("logcat").filter(Level.ALL);
	        File logFile = new File("E:\\Bala\\git-repo\\Atom\\Results\\test.txt");
	        ;
			try {
				PrintWriter log_file_writer = new PrintWriter(logFile);
				 log_file_writer.println(logEntries );
			      log_file_writer.flush();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        */
		atom.mobile().end();
    }
    
    public static void logSetup() {	
		try {
			String logFilePath = atom.environment().paths().runResults()+"testlog.txt";
			File logFile = new File(logFilePath);
			logFile.createNewFile();
			System.out.println("Atom INFO :: Test log will be stored in the location "+logFilePath);
			System.setOut(new PrintStream(new FileOutputStream(logFilePath, true)));
			System.setErr(new PrintStream(new FileOutputStream(logFilePath, true)));
		} catch(Exception e) {
			System.out.println("Atom INFO :: Problem while creating test log file "+e.getMessage());
		}
	}
    
    public void printTestInfo(String text) {
    	System.out.println("Atom INFO "+LocalDateTime.now()+" :: [Test Runner] "+text);
    }
}