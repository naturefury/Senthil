package utilities;

public class AtomException extends Exception {
	 
	private static final long serialVersionUID = 1L;

	public AtomException(String message) {
        super(message);
    }
}
