class RubyBasics

  puts "Welcome to RUBY Basics" 
  
  
  #Single line comment
  puts "Single line comment" 
  
=begin
  
  Comment Line 1
  Comment Line 2
  Multiple line comment
  
=end
  
end

BEGIN{
  
  puts "Program began"
  
}

END{
  
  puts "Program Ended"
  
}