class StringMethods

  first_name = 'Balabharathi'
  last_name = 'Jayaraman'
  native_place = 'Chengalpet'
  country = '    united states of america      '
  state = 'New York'
  
  
  puts 'UPPER CASE: ' + first_name.upcase
  puts 'LOWER CASE: ' + last_name.downcase
  puts 'DELETE: ' + native_place.delete('e')
  puts 'COUNTRY: ' + country.capitalize
  puts 'REVERSE: ' + state.reverse()
  puts country.length()
  puts country.strip()
  puts country
  
  puts country.gsub('states','kingdom')
  
  
  
  
  
  
end