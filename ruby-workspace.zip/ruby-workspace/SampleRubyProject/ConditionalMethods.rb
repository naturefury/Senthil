class ConditionalMethods
  
  total_mark = 400
  cut_off = total_mark/5
  puts cut_off
  
  if cut_off >= 95
    
    puts 'AAA GRADE'
    
  elsif cut_off >= 80 && cut_off < 95
    
    puts 'A+ GRADE'
    
  elsif cut_off >= 75 && cut_off < 80
    
    puts 'A GRADE'
    
  else
    
    puts 'FAIL'
    
  end
  
end