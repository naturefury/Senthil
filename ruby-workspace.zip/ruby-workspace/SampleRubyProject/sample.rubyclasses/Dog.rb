class Dog
 
  def initialize(name)
    
    @dog_name = name
    
  end
  
  def bark()
    
    puts @dog_name + " is barking !!! "
    
  end
  
  def walk()
    
    puts @dog_name + " is walking !!! "    
    
  end
  
  def eat(food_name)
      
      puts @dog_name + " is eating " + food_name    
      
  end
  
  def run()
    
    puts @dog_name + " is running !!! "  
    
  end
  
end

  Alex = Dog.new("Alex")
  
  Alex.bark()
  
  Alex.eat("Red meat")
  
  Alex.run()
  
  Alex.walk()
















