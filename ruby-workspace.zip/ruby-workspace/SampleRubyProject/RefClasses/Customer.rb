class Customer
  
  @@no_of_customers = 0 
  
  def initialize (id,name,emp_id)
    
    @cust_id = id
    @cust_name = name
    @cust_emp_id = emp_id
    
    @@no_of_customers = @@no_of_customers + 1
    
    puts "Customer " + @cust_name + ", is added along with the details " + @cust_id + " & his employee id " + @cust_emp_id
    puts @@no_of_customers
    
  end
  
  def print_cust_name()
    
    puts "CUSTOMER NAME IS: " + @cust_name
    
  end
  
end