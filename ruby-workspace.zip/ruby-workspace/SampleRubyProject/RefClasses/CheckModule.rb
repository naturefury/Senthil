require_relative "RefClasses/SampleModule.rb"

class CheckModule
  
  include SampleModule
  
end


big1 = Sample.new()
big1.a1
