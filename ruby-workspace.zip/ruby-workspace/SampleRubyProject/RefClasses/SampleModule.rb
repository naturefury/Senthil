module SampleModule
  
  def a1
    
    puts "a1"
    
  end
  
  def a1
    
    puts "a2"
      
  end
  
end