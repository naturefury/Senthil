message = "Welcome to ruby !"
puts message
message = "You are going in the right direction, learning is always the key to success."
puts message
message = "Wish you all the best"
puts message

puts "**************************************************************"
puts 3 * 6
puts "Dash" || "Test"
puts test_variable ||="Nothing"
puts `dir`
puts "**************************************************************"
puts system("java -version")
puts "**************************************************************"
puts system("mvn -version")
puts "**************************************************************"
puts system("ruby -v")
puts 'It\'s my ruby'

=begin
puts "In which city do you stay?"  
STDOUT.flush  
city = gets.chomp  
puts "The city is " + city  




#Arithmetic Operators

+ addition  
- subtraction  
* multiplication  
/ division  

=end