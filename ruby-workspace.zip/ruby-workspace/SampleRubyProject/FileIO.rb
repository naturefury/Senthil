class FileIO
  
  def create(filename)
   
    @aFile = File.new(filename,"w")
    
  end
  
  def write(text)
    
    @aFile.syswrite(text)
    
  end
  
  def read(filename)
    begin
      
      @aFile = File.open(filename,"r")
      @aFile.each { |line|
         puts line
      }
       
    rescue  
      #raise("File not found")
      puts "File not found"
    end
    
  end
  
  def close()
    
    @aFile.close
    
  end
    
end

NewFile = FileIO.new()
NewFile.create("E:\Bala\ruby-workspace\SampleRubyProject\Ruby.txt")
NewFile.write("Hey, Welcome 2018!")
NewFile.write("I'm Bala")
NewFile.write("Bye")
NewFile.read("Rud")
NewFile.close