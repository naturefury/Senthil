#Addition Method **************************
def add (a,b)
  
  c = a + b
  return c
  
end

def greetings(name)
  
  greeting_text = "Welcome " + name + ", Have a nice day!"
  
end

puts "Addition of 2 and 5 is #{add(2,5)}"

guest_names = ["Rock","Steve Austin","Kurt Angle","3 H","Brock Lesnar"]
  
  
for i in guest_names
  
  puts "------------------------------------------"
  puts greetings(i) 
  puts "------------------------------------------"
  
end

guest_names.each() { |person|
  
  puts "--------------NEW-------------------------"
  puts greetings(person) 
  puts "------------------------------------------"
  
}



