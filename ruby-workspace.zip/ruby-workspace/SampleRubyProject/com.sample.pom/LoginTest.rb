require_relative "pages/LoginPage.rb"

class LoginTest
  
  puts "################# Test execution started ! #################"
  
  browser = LoginPage.new("E:/Bala/sel-webdrivers/chromedriver.exe")
  
  browser.goto("https://www.google.com")
  
  browser.google_searchbox().send_keys "TestProject.io"
  
  browser.google_searchbox().submit
  
  browser.close_browser()
  
  puts "################# Test execution completed ! #################"
  
end