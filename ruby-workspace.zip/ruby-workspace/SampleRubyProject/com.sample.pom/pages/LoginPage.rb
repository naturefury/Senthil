require "selenium-webdriver"

class LoginPage
  
  #Initialization method
  def initialize(webdriver_path)
    
    Selenium::WebDriver::Chrome.driver_path = webdriver_path
    @driver = Selenium::WebDriver.for :chrome
    @driver.manage.window.maximize
    puts "Chrome browser is opened"
    
  end
  
  #Goto the a specific URL
  def goto(url)
    
    @driver.navigate.to url
    puts "Navigating to " + url
    
  end
  
  #Google Search Box 
  def google_searchbox()
    
    return @driver.find_element(:name, 'q')
    
  end
  
  #Method to quit the browser
  def close_browser()
    
    @driver.quit
    puts "Browser is closed"
    
  end
  
end