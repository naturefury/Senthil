class IntegerMethods
  
  country = 'United States'
  rank = 1
  even_no = 23
  odd_no = 42
  
  puts even_no.even?
  puts odd_no.odd?
  puts country
  puts rank
  puts rank.to_f
  puts 'The '+country+' is in rank '+rank.to_s
  
end