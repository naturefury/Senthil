require_relative "RefClasses/Customer.rb"

class LearnRubyVariables
  
  cust_1 = Customer.new("CUST001","Bala","TG2259")
  
  cust_2 = Customer.new("CUST002","Ragu","TG1505")
  
  cust_1.print_cust_name()
  
  cust_2.print_cust_name()
  
  #Special varaibles
  
  puts __FILE__
  
  puts __LINE__
  
  puts ?\n + "NEW LINE"
    
  
  
  puts "escape '\\'"
  
  puts "Result of 3 * 2 is #{3*2}"

  rArray = ["Bala","TG2259","Automation Tester"]
    
  rArray.each do |i|
    
    puts i
    
  end
  
  
  hsh = rHshArray = {"Name"=>"Bala","Emp ID"=>"TG2259","Role"=>"Automation Tester"}
  hsh.each do |key,value|
    
    print key, " is ", value, "\n"
    
  end
 
end


