class Looping
  
  for i in 1..5
    
    puts "I'm number : #{i}"
    
  end
  
  puts "*******************************************"
  
  i = 40
  x = 50
  
  until i >= 50 do
    
    puts "Will loop until #{x}, current sequence is #{i}"
    i += 1
    
  end
  
  puts "*******************************************"
    
  for i in 1..7
    
    if i > 2 then
     
      puts "i is greater than 2 : #{i}"        
      
    end
    
  end
  
  puts "*******************************************"
    
  employee_name = Array.new(10)
     
  employee_name[0] = "Balabharathi Jayaraman"
  employee_name[1] = "Elon Musk"
  employee_name[2] = "Steve Jobs"
  employee_name[3] = "Sundar Pichai"
  employee_name[4] = "Ragunathan Palanisamy"
  employee_name[5] = "VC"
  employee_name[6] = "Sebastin Valarian"
  employee_name[7] = "Afroz Shaik"
  employee_name[8] = "James Sutherland"
  employee_name[9] = "Rovan Powell"   
    
  for i in employee_name
    
    puts "Emplopyee name : #{i}"
    
  end  
  
  20.times {
    
    puts "Welcome !"
    
  }
 
end