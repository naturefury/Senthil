class Hashes
  
  student_info = {"Bala"=>"I001","Sebastin"=>"I002","Ragu"=>"I003"}
    
    puts student_info.keys() 
    puts "*******************************"
    puts student_info.values()
  
  
end