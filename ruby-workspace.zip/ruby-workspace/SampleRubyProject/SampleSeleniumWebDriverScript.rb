require "selenium-webdriver"

class SampleSeleniumWebDriverScript
  
  chromedriver_path =  "E://Bala/sel-webdrivers/chromedriver.exe" #Chrome web driver executable path
  
  #Launching web driver
  Selenium::WebDriver::Chrome.driver_path = chromedriver_path
  driver = Selenium::WebDriver.for :chrome
  driver.manage.window.maximize
  driver.navigate.to "http://google.com"
  
  #Now web driver is launched, so we can do the operations for the test
  element = driver.find_element(:name, 'q')
  element.send_keys "TestProject.io"
  element.submit
  
  puts "Web page title is : " + driver.title
  
  #Driver is closing
  driver.quit
  
  puts "Test passed !!!, Happy testing"
  
end