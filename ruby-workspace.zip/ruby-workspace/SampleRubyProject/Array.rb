class Array
  
  student_name = ["John","Bala","Wasim Akram","Thisera Perara","Virat Kohli"]
   
  puts student_name[0]
  
  puts "***************************"
  
  puts student_name  

  puts "***************************"
  
  puts "# Array is sorted "
  
  puts student_name.sort
  
  puts "***************************"
  
  student_id = Array.new
  
  student_id[0] = "TG2259"
  student_id[1] = "TG2254"
  student_id[2] = "CA1234"
  
  puts student_id
  
  puts "***************************"
  
  puts student_id.empty?()
  
  puts "***************************"
  
  puts "Empty array with defined size"
  
  puts "***************************"
  
  employee_name = Array.new(10)
  
  employee_name[0] = "Balabharathi Jayaraman"
  employee_name[1] = "Elon Musk"
  employee_name[2] = "Steve Jobs"
  employee_name[3] = "Sundar Pichai"
  employee_name[4] = "Ragunathan Palanisamy"
  employee_name[5] = "VC"
  employee_name[6] = "Sebastin Valarian"
  employee_name[7] = "Afroz Shaik"
  employee_name[8] = "James Sutherland"
  employee_name[9] = "Rovan Powell"   
  
  puts employee_name

end


