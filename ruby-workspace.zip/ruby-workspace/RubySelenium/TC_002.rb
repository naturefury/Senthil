require 'test/unit' 


class TC_001_Verify_Login_Functionality < Test::Unit::TestCase
  
  def testCase1
    
    puts 'Sign In button clicked'
    puts 'Username entered'
    puts 'Password entered'
    puts 'Login button clicked'
    assert_true(false,"ERROR: Value is not matching ....")
    
  end
  
  def testCase2
      
      puts 'Test Case 2 started'
      puts 'Test Case 2 completed'
      
    end
  
  
  def setup
    
    puts 'Starting browser , navigating to the URL'
    
  end
  
  def teardown
    
    puts 'Close the browser'
    
  end
 
end