require 'selenium-webdriver'

#Driver initialization ----------------------------------------------------------------------------------------------
Selenium::WebDriver::Chrome.driver_path='E:\Bala\java-workspace\bdd-cucumber-java\src\BrowserDrivers\chromedriver.exe'
Browser=Selenium::WebDriver.for :chrome
Browser.manage.window.maximize
Browser.get('https://demo.cyclos.org/')
