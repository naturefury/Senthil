class A
  
  def SayHello
    
    puts "Hello ...... !"
    
  end
  
  def self.classmethod
    
    puts "Hey ! this is a class method" 
    
  end
  
end