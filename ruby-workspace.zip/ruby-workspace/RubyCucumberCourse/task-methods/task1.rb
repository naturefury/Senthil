require "./maths.rb"
  
  obj = Maths.new("Bala")
  a = obj.add(20,100)
  b = obj.sub(20,10)
  puts "Result of (20+100) * (20-10) is #{obj.multiply(a,b)}"
  puts "***************************************************"
  s = obj.square(2)
  c = obj.cube(3)
  puts "Result of Square(2) + Cube(3) is #{obj.add(s,c)}"
  puts "***************************************************"
