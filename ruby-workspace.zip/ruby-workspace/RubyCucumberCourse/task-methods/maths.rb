class Maths
  
  def initialize (arg1)
   
    puts "Hey, " + arg1.upcase()
     
  end
  
  def add(a,b)
    
    c=a+b
    return c
    
  end
  
  def sub(a,b)
    
    c=a-b
    return c
    
  end
  
  def multiply(a,b)
  
    c=a*b
    return c
    
  end
  
  def square(a)
    
    c = a * a
    return c
    
  end
  
  def cube(a)
    
    c = a * a * a
    return c
    
  end
 
end