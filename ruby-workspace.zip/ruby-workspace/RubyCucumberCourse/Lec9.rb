puts "My test code ...."

BEGIN{
 
  puts "Begin code"
   
}

END{
  
  puts "End code"
  
}
 