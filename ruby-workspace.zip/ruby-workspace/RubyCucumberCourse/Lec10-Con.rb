require "./Lec10"

obj = A.new()
obj.SayHello()
A.classmethod