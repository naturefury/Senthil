require 'yaml'

config = YAML.load_file("./configuration/config.yml")


puts "Application URL is " + config['Application_URL']
puts "User Phone number is " + config['User_Phone']