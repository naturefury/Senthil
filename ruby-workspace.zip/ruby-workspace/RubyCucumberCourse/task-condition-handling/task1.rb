

obj = CompareNumbers.new()
m = obj.find_the_largest(10,20,30)
puts "The largest number is #{m}"




class CompareNumbers
   
  def find_the_largest(a,b,c)
    
    if (a > b && a > c)
      
      return a
      
      elseif (b > a && b > c)
      
      return b
      
    else 
      
      return c
      
    end
   
  end
  
end

