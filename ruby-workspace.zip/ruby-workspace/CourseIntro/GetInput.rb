puts "Hey Dude, Let's introduce ourselves .... My name is Ruby, Yours?"
Username = gets
puts "Welcome #{Username.upcase()} , Have a nice time in Ruby coding, If you use me well. I will look like a magic!"