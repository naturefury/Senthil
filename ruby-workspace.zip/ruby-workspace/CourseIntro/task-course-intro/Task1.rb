puts "Hi, enter your Firstname ...."
first_name = gets
puts "and your Lastname ....?"
last_name = gets
print "Welcome #{first_name.upcase()} , #{last_name.upcase()}"