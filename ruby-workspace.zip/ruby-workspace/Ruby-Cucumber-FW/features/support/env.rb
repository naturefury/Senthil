require './utilities/InitializeBrowser.rb'

Before do
  
  @Browser = InitializeBrowser.new
  @Browser.openBrowser("Chrome")
  
end

After do
  
  @Browser.closeBrowser
  
end