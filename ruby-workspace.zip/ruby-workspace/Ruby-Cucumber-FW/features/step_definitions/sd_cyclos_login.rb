Given("I navigate to {string}") do |string|                                    
  
  
  
end                                                                            

Given("I click Sign In link") do
  
  
  
end

Given("Enter Username {string} and Password {string} and click Sign In") do |string, string2|
  
  
  
end

Then("I should see My Account home page") do
  
  
  
end