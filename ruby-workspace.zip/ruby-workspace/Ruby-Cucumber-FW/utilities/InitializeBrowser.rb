require 'selenium-webdriver'

class InitializeBrowser
  
  $Browser

  def openBrowser(brower_name)
    if(brower_name.upcase == "CHROME")
      openChrome
    elsif (brower_name.upcase == "IE")
      openIE
    elsif (brower_name.upcase == "FIREFOX")    
      openFirefox
    end
  end
  
  def openChrome
    Selenium::WebDriver::Chrome.driver_path = './webdrivers/chromedriver.exe'
    $Browser = Selenium::WebDriver.for :chrome
    $Browser.manage.window.maximize
  end
  
  def openIE
    puts "No code has been added to initialize IE browser!!!"
  end
  
  def openFirefox
      puts "No code has been added to initialize FIREFOX browser!!!"
  end
  
  def closeBrowser
    $Browser.quit
  end
  
end