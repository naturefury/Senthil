package com.sqs.fnb.cyclosdemo.features.steps;

import java.util.ArrayList;
import java.util.List;

import com.sqs.fnb.cyclosdemo.features.helper.CyclosHelper;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.model.DataTable;

public class CyclosTestSteps {
	
	CyclosHelper myself;
	
	@Given("^I am on Cyclos site$")
	public void i_am_on_Cyclos_site() throws Exception {
		myself.open();
	}


	@When("^I click Sign in link$")
	public void i_click_Sign_in_link() throws Exception {
		myself.click_SignIn_link();
	}

	@Then("^I should see login screen$")
	public void i_should_see_login_screen() throws Exception {
		myself.verify_If_Login_Screen_Appeared();
	}

	@When("^I enter valid credentials$")
	public void i_enter_valid_credentials() throws Exception {
		myself.enter_UserID();
		myself.enter_Password();
	}

	@When("^I click on login button$")
	public void i_click_on_login_button() throws Exception {
		myself.click_SignIn_Button();
	}

	@Then("^I should see my page$")
	public void i_should_see_my_page() throws Exception {
		myself.verifyHomePage();
	}
	
	@Then("^Click Logout$")
	public void click_Logout() throws Exception {
	    myself.click_Logout();
	    Thread.sleep(5000);
	}
	
	
	
	
	@When("^I should enter (.*) and (.*)$")
	public void i_should_enter(String userid, String password) throws Exception {
	    myself.enter_UserID(userid);
	    myself.enter_Password(password);
	}
	
	@When("^I click on login button with valid credentials$")
	public void i_click_on_login_button_with_valid_credentials() throws Exception {
	    myself.enter_UserID("demo");
	    myself.enter_Password("1234");
	    myself.click_SignIn_Button();
	}


	@When("^I click on login button with invalid credentials$")
	public void i_click_on_login_button_with_invalid_credentials() throws Exception {
		myself.enter_UserID("test");
		myself.enter_Password("test");
		myself.click_SignIn_Button();
	}

	@Then("^I should see validation message$")
	public void i_should_see_validation_message() throws Exception {
		myself.verify_Validation_Message();
	}

	@Then("^I should see corresponding links$")
	public void i_should_see_corresponding_links(List<String> arg1) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
	    // E,K,V must be a scalar (String, Integer, Date, enum etc)

		myself.verify_Links(arg1);
		
		for(int i=0;i<arg1.size();i++){
			System.out.println(arg1.get(i));
		}
	}
	
}
