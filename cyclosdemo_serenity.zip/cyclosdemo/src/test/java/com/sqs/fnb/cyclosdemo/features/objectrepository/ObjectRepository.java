package com.sqs.fnb.cyclosdemo.features.objectrepository;

import net.thucydides.core.annotations.findby.FindBy;
import net.thucydides.core.pages.PageObject;
import net.thucydides.core.pages.WebElementFacade;

public class ObjectRepository extends PageObject {
	@FindBy(linkText="Sign in")
	public WebElementFacade signIn_link;
	
	@FindBy(xpath="//input[@type='text' and @class='inputField medium']")
	public WebElementFacade userID_TextBox;
	
	@FindBy(xpath="//input[@type='password']")
	public WebElementFacade password_TextBox;
	
	@FindBy(xpath="//button")
	public WebElementFacade signInButton;
	
	@FindBy(linkText="Logout")
	public WebElementFacade logout_link;
	
	@FindBy(linkText="Register")
	public WebElementFacade Menu_Link_0;
	
	@FindBy(linkText="Sign in")
	public WebElementFacade Menu_Link_1;
	
	@FindBy(linkText="free community currency")
	public WebElementFacade Menu_Link_2;
	
	@FindBy(linkText="integrated SMS module")
	public WebElementFacade Menu_Link_3;
	
	@FindBy(linkText="forum")
	public WebElementFacade Menu_Link_4;
}
