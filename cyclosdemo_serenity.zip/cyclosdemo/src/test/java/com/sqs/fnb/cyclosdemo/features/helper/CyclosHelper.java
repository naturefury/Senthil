package com.sqs.fnb.cyclosdemo.features.helper;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;

import com.sqs.fnb.cyclosdemo.features.objectrepository.ObjectRepository;

import cucumber.api.TableConverter;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.annotations.findby.By;
import net.thucydides.core.model.DataTable;

@DefaultUrl("https://demo.cyclos.org/")
public class CyclosHelper extends ObjectRepository{

	WebDriver driver=getDriver();

	public void click_SignIn_link() throws Exception {
		waitFor(ExpectedConditions.titleContains("Cyclos 4 Demo - Cyclos4 Communities"));
		signIn_link.click();
	}

	//Check Login Page
	public void verify_If_Login_Screen_Appeared() throws Exception {
		waitFor(ExpectedConditions.titleContains("System login - Cyclos4 Communities"));
		Assert.assertEquals(getDriver().getTitle(),"System login - Cyclos4 Communities");
	}

	public void enter_UserID() throws Exception {
		userID_TextBox.sendKeys("demo");
	}
	public void enter_Password() throws Exception {
		password_TextBox.sendKeys("1234");
	}
	
	public void enter_UserID(String userid) throws Exception {
		userID_TextBox.sendKeys(userid);
	}
	public void enter_Password(String password) throws Exception {
		password_TextBox.sendKeys(password);
	}
	
	public void click_SignIn_Button() throws Exception {
		signInButton.click();
	}
	
	//Check Homepage
	public void verifyHomePage() throws Exception {
//		Thread.sleep(10000);
		waitFor(ExpectedConditions.titleIs("Cyclos4 Communities"));
		Assert.assertEquals(getDriver().getTitle(),"Cyclos4 Communities");
	}
	
	public void click_Logout() throws Exception {
		waitFor(ExpectedConditions.titleIs("Cyclos4 Communities"));
		logout_link.click();
	} 

	//Check validation message
	public void verify_Validation_Message() throws Exception {
		Assert.assertEquals(element(By.xpath("//div[@class='notificationContainer']/div/div")).getText(),"The given name / password are incorrect. Please, try again.");
	}
	
	//Check Links
	public void verify_Links(List<String> arg1) {
		List<String> actual_links = new ArrayList();
		actual_links.add(Menu_Link_0.getText());
		actual_links.add(Menu_Link_1.getText());
		actual_links.add(Menu_Link_2.getText());
		actual_links.add(Menu_Link_3.getText());
		actual_links.add(Menu_Link_4.getText());
		
		Assert.assertEquals(actual_links, arg1);
	}
	
	void enterText(String accessType,String accessVal,String textVal){
		if(accessType.contains("class")){
			element(By.className(accessVal)).sendKeys(textVal);
		}
		else if(accessType.contains("css")){
			element(By.cssSelector(accessVal)).sendKeys(textVal);
		}
		else if(accessType.contains("id")){
			element(By.id(accessVal)).sendKeys(textVal);
		}
		else if(accessType.contains("link")){
			element(By.linkText(accessVal)).sendKeys(textVal);
		}
		else if(accessType.contains("name")){
			element(By.name(accessVal)).sendKeys(textVal);
		}
		else if(accessType.contains("partiallink")){
			element(By.partialLinkText(accessVal)).sendKeys(textVal);
		}
		else if(accessType.contains("tag")){
			element(By.tagName(accessVal)).sendKeys(textVal);
		}
		else if(accessType.contains("xpath")){
			element(By.xpath(accessVal)).sendKeys(textVal);
		}
	}

	void buttonClick(String accessType,String accessVal){
		if(accessType.contains("class")){
			element(By.className(accessVal)).click();
		}
		else if(accessType.contains("css")){
			element(By.cssSelector(accessVal)).click();
		}
		else if(accessType.contains("id")){
			element(By.id(accessVal)).click();
		}
		else if(accessType.contains("link")){
			element(By.linkText(accessVal)).click();
		}
		else if(accessType.contains("name")){
			element(By.name(accessVal)).click();
		}
		else if(accessType.contains("partiallink")){
			element(By.partialLinkText(accessVal)).click();
		}
		else if(accessType.contains("tag")){
			element(By.tagName(accessVal)).click();
		}
		else if(accessType.contains("xpath")){
			element(By.xpath(accessVal)).click();
		}
	}
	
	void clickLink(String accessType,String accessVal){
		if(accessType.contains("class")){
			element(By.className(accessVal)).click();
		}
		else if(accessType.contains("css")){
			element(By.className(accessVal)).click();
		}
		else if(accessType.contains("id")){
			element(By.id(accessVal)).click();
		}
		else if(accessType.contains("link")){
			element(By.linkText(accessVal)).click();
		}
		else if(accessType.contains("name")){
			element(By.name(accessVal)).click();
		}
		else if(accessType.contains("partiallink")){
			element(By.partialLinkText(accessVal)).click();
		}
		else if(accessType.contains("tag")){
			element(By.tagName(accessVal)).click();
		}
		else if(accessType.contains("xpath")){
			element(By.xpath(accessVal)).click();
		}
	}

	
}
