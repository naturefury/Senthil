package net.sf.com.steps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.sf.com.steps.serenity.EndUserAtend;

public class defi1 {
	 EndUserAtend EndUser;
	    @Given("^user open page$")
	    public void user_open_page() throws Exception {
	       EndUser.is_the_homepage();
	    }


	    @When("^user enters in userNameField as 'demo'$")
	    public void user_enters_in_userNameField_as_demo(String userName) throws Exception {
	    	EndUser.enter_user_name(userName); 
	       
	    }

	    @When("^user enters  in passWordField as '(\\d+)'$")
	    public void user_enters_in_passWordField_as(String Upwd) throws Exception {
	    	EndUser.enter_user_password(Upwd);
	    }

	    @Then("^user clicked on SignInBUtton$")
	    public void user_clicked_on_SignInBUtton() throws Exception {
	       EndUser.click_signin();
	    }


	

}
