package net.sf.com.steps;

import net.thucydides.core.annotations.Steps;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.sf.com.steps.serenity.EndUserAtend;
import net.sf.com.steps.serenity.EndUserSteps;

public class DefinitionSteps {

    @Steps
    EndUserSteps anna;

    @Given("the user is on the Wikionary home page")
    public void givenTheUserIsOnTheWikionaryHomePage() {
        anna.is_the_home_page();
    }

    @When("the user looks up the definition of the word '(.*)'")
    public void whenTheUserLooksUpTheDefinitionOf(String word) {
        anna.looks_for(word);
    }

    @Then("they should see the definition '(.*)'")
    public void thenTheyShouldSeeADefinitionContainingTheWords(String definition) {
        anna.should_see_definition(definition);
    }
    
    @Given("^user is on application landing page as \"([^\"]*)\"$")
    public void user_is_on_application_landing_page_as(String arg1) throws Exception {
    	
       
    }


    @When("^user enters in userNameField as \"([^\"]*)\"$")
    public void user_enters_in_userNameField_as(String arg1) throws Exception {
        
    }

    @When("^user enters  in passWordField as \"([^\"]*)\"$")
    public void user_enters_in_passWordField_as(String arg1) throws Exception {
        
    }

    @When("^user clicked on \"([^\"]*)\"$")
    public void user_clicked_on(String arg1) throws Exception {
       
    }

    @Then("^user should able to see Welcome to cyclose message with \"([^\"]*)\"$")
    public void user_should_able_to_see_Welcome_to_cyclose_message_with(String arg1) throws Exception {
       
    }


//=====================
    EndUserAtend EndUser;
    @Given("^user open page$")
    public void user_open_page() throws Exception {
       EndUser.is_the_homepage();
    }


    @When("^user enters in userNameField as 'demo'$")
    public void user_enters_in_userNameField_as_demo() throws Exception {
    	EndUser.enter_user_name(); 
       
    }

    @When("^user enters  in passWordField as '(\\d+)'$")
    public void user_enters_in_passWordField_as(int arg1) throws Exception {
    	EndUser.enter_user_password();
    }

    @Then("^user clicked on SignInBUtton$")
    public void user_clicked_on_SignInBUtton() throws Exception {
       EndUser.click_signin();
    }


}
