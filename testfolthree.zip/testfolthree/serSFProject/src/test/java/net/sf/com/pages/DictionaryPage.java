package net.sf.com.pages;

import org.junit.Assert;


import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.DefaultUrl;

@DefaultUrl("https://demo.cyclos.org/#login")
public class  DictionaryPage extends PageObject {
	
	
	@FindBy(className="inputField medium") 
	private WebElementFacade UserField;
	
	@FindBy(className="inputField passwordField authenticationInput medium") 
	private WebElementFacade PassswordField;
	
	@FindBy(className="actionButtonText") 
	private WebElementFacade SignIn;
	
	@FindBy(className="pageSectionHeading") 
	private WebElementFacade HomePageVerify;
	
public void login_page_Valiadtion(){
	
	Assert.assertEquals(LoginpageText.getText(), "System login");
}
public void username_Entering(String UName){
	UserField.sendKeys("demo");
}

public void password_Entering(String UPswd){
	PassswordField.sendKeys("1234");
}
public void click_On_SignIn(){
	SignIn.click();
}

public void verify_Hompage_Text(String HPageTXT ){
	Assert.assertEquals(LoginpageText.getText(), "Welcome to the Cyclos4 Demo");
	
}
public void lookup_terms() {
	// TODO Auto-generated method stub
	
}



}

