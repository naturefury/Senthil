package net.sf.com.steps.serenity;

public class EndUserAtend {

	public void is_the_homepage() {
		// TODO Auto-generated method stub
		
	}

	public void enter_user_name(String userName) {
		// TODO Auto-generated method stub
		
	}
	public void enter_user_password(String upwd) {
		// TODO Auto-generated method stub
		
	}
	public void click_signin() {
		// TODO Auto-generated method stub
		
	}

	

}
