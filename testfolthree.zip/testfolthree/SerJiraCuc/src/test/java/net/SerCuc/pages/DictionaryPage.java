package net.SerCuc.pages;

import org.junit.Assert;


import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.DefaultUrl;
@DefaultUrl("https://demo.cyclos.org/#login")   
public class DictionaryPage extends PageObject{
           
	    @FindBy(className = "pageHeadingText")
	    private WebElementFacade FHeadingText;
	    
	    @FindBy(xpath = "/html/body/div[3]/div[3]/div/div/div[2]/div[2]/div[2]/div/div/div/div[2]/div/input")
	    private WebElementFacade userNameField;
	    
	    @FindBy(xpath = "/html/body/div[3]/div[3]/div/div/div[2]/div[2]/div[2]/div/div/div/div[2]/div/div[4]/input")
	    private WebElementFacade passWordField;
	    
	    @FindBy(className = "actionButtonText")
	    private WebElementFacade SignInButton;
	    
	    @FindBy(className = "pageSectionHeading")
	    private WebElementFacade WelcomeHomePage;


	    
	    public void HomePageTextValidation() {
	    	Assert.assertEquals("System login", FHeadingText.getText());
	    	System.out.println("Captured text is "+FHeadingText.getText());
	    	                             
	    }
	    
	    public void enterUserName(String userName) {
	    	userNameField.type(userName);
	    		
	    }
	    
	    public void enterpassWord(String passWord) {
	    	passWordField.sendKeys(passWord);
	    	
	    }
	    	 public void clickOnSignIn() {
	 	    	SignInButton.click();
	    	 }
	 	    	 public void verifyHomePageTextOfWelcomeScreen() {
	 	    		String HomeText ="Welcome to the Cyclos4 Demo";
	 	    		Assert.assertEquals(HomeText, HomeText);
	 	    		System.out.println("Finally reached the page "+HomeText);
	    	
	                              
	    }
	}

