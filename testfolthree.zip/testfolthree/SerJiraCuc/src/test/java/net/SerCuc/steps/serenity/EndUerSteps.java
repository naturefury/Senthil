package net.SerCuc.steps.serenity;

import net.SerCuc.pages.DictionaryPage;
import net.SerCuc.pages.UpdateProfilePage;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasItem;

public class EndUerSteps {

	DictionaryPage loginpage;
	UpdateProfilePage updateProfilepage;
	
	@Step
	public void open_HomePage(){
		loginpage.open();
		loginpage.HomePageTextValidation();
		}
	@Step
	public void enter_UserName(String userName){
		loginpage.enterUserName(userName);
	}
	
	@Step
	public void enter_password(String passWord){
		loginpage.enterpassWord(passWord);
	}
	@Step
	public void click_On_SignIn(){
		loginpage.clickOnSignIn();
	}
	
	@Step
	public void verify_Welcome_message(){
		loginpage.verifyHomePageTextOfWelcomeScreen();
	}
	public void click_on_updateProfile() {
		updateProfilepage.updateProfilelinkElement();
		
	}
	public void Select_DROPDOWN_print(String BusinText) {
		updateProfilepage.businessTypeElement(BusinText);
		
	}
	public void user_click_on_save() throws InterruptedException {
		updateProfilepage.savebtnElement();
		
	}
	public void user_click_on_logout() {
		updateProfilepage.logOutElement();
		
	}
	
}
