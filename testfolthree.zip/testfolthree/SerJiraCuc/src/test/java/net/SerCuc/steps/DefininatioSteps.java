package net.SerCuc.steps;


import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.SerCuc.steps.serenity.EndUerSteps;
import net.thucydides.core.annotations.Steps;

public class DefininatioSteps {
	
	@Steps
	EndUerSteps Enduser;
	
	@Given("user is on application landing page  as System login")
	public void user_is_on_application_landing_page_as() throws Exception {
		Enduser.open_HomePage();
		
	}

	@When("user enters in userNameField as '(.*)'")
	public void user_enters_in_userNameField_as(String userName) throws Exception {
		Enduser.enter_UserName(userName);
	   
	}

	@When("^user enters  in passWordField as '(.*)'")
	public void user_enters_in_passWordField_as(String passWord) throws Exception {
		Enduser.enter_password(passWord);
	}

	@When("user clicked on SignInBUtton")
	public void user_clicked_on_SignInBUtton() throws Exception {
		Enduser.click_On_SignIn();
	    
	}

	@Then("user should able to see Welcome to cyclose message with Welcome to the CyclosDemo")
	public void user_should_able_to_see_Welcome_to_cyclose_message_with_Welcome_to_the_CyclosDemo() throws Exception {
		Enduser.verify_Welcome_message();
	}

@Given("when user is availble with welcomescreen")
public void when_user_is_availble_with_welcomescreen() throws Exception {	
	//Enduser.open_HomePage(); 
}

@When("^user should click on update profile$")
public void user_should_click_on_update_profile() throws Exception {
	Enduser.click_on_updateProfile();
   }


@When("^user should able to Print all dropdown option and select '(.*)'$")
public void user_should_able_to_Print_all_dropdown_option_and_select_Financial(String BusinText) throws Exception {
	Enduser.Select_DROPDOWN_print(BusinText);
}

@When("^user should click on save button$")
public void user_should_click_on_save_button() throws Exception {
	Enduser.user_click_on_save();
}

@Then("^user shoud click on LogOut$")
public void user_shoud_click_on_LogOut() throws Exception {
	Enduser.user_click_on_logout();
}

}


