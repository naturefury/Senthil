package net.SerCuc.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class UpdateProfilePage extends PageObject {
	
	    @FindBy(xpath = "/html/body/div[3]/div[3]/div/div/div[2]/div[2]/div[2]/div/div/div[1]/div[1]/a[2]/table/tbody/tr/td/div")
	    private WebElementFacade UpdateProfile_Link;
	    
	    @FindBy(xpath = "/html/body/div[3]/div[3]/div/div/div[2]/div[2]/div[2]/div/div/div/table/tbody/tr[6]/td[2]/div/div[1]")
	    private WebElementFacade BusinessType_dropDown;
	    
	    @FindBy(xpath = "/html/body/div[3]/div[3]/div/div/div[2]/div[2]/div[2]/div/div/div/table/tbody/tr[8]/td/div/div[3]/button/div")
	    private WebElementFacade Save_Btn;
	    
	    @FindBy(xpath = "/html/body/div[3]/div[1]/div/ul/li[4]/a/span")
	    private WebElementFacade LogOut_Link;
	    
	    
	    public void updateProfilelinkElement() throws InterruptedException{
	    	UpdateProfile_Link.click();
	    	Thread.sleep(4000);
	    		    	
	    }
	     public void businessTypeElement(String BusinText){
	    	
	    	 Select businessOption =new Select(BusinessType_dropDown);
	    	 List<WebElement> businessOptionAll=businessOption.getOptions();
	    	 int Optionssize=businessOptionAll.size();
	    	 for (int i=0; i<Optionssize;i++){
	    		 System.out.println("The total options siz is "+Optionssize);
	    		 System.out.println("The list of options are "+businessOptionAll.get(i).getText());	 
	    	 }
	    	 BusinessType_dropDown.sendKeys(BusinText); 
	     }
	     
	     public void savebtnElement() throws InterruptedException{
	    	 Save_Btn.click();
	    	 Thread.sleep(2000);
	     }
	      public void logOutElement(){
	    	  LogOut_Link.click();
	    	  System.out.println("Successfully user logged out");
	      }
}
