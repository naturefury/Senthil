package serenitylabs.tutorials.trains.search;

public enum SeasonTicketDuration {
    Weekly, Monthly, Annual
}
